#define BUFFER_SIZE 5
typedef int buffer_item;