
clear

node PolygonTriangulate.js testcrazy.json outputcrazy.json


