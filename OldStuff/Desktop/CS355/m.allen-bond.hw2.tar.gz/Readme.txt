Michael Allen-Bond
SID 011386199
michael.allen-bond@email.wsu.edu
CS 355
Dr. Dang
Assignment 2

This program takes in 3-SAT problems and spits out solutions.  The 3-SAT problem is a set of clauses, each containing 3 variables with either true or false values, combined with a state, a list of all variables, with their values set to true or false. The objective is to change the boolean values of the variables in the state such that all the clauses in the 3-SAT set have at least one variable that matches its state value, making that clause true.  If all the clauses are true, then the 3-SAT problem is solved.  The program solves this problem by utilizing a recursive hill-climbing algorithm to  find incrementally better solutions to the problem until a complete solution is achieved, or maximum search depth is reached.

Included files:
	Readme.txt
	HW2.rkt
