Michael Allen-Bond
m.allen-bond@email.wsu.edu
CSE 330

numerical integration functions for approximating pi

This program displays reduction in error for various numerical integration approximations of pi as the number of divisions (n) increases.  To compile the program, simply type "make", and the included Makefile should do the rest.

Output displays n partitions, Trap error, simpsons error, simpsons 3/8 error, and boole's error.


Files in Archive:
Makefile
README
pi.c

