Michael Allen-Bond
michael.allen-bond@email.wsu.edu

CSE 330
Homography program for 4 coordinates

This program takes in 8 sets of coordinates, 4 initial, and 4 final, and then creates a matrix to map them to eachother.  To compile, type "make", to run with test file (included), type "./homography < boxtop.in".

Files Included:
README
homography.c
Makefile
boxtop.in
LUdecomp.c
LUdecomp.h

