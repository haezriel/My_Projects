#include "LUdecomp.h"
#include <stdio.h>
#include <math.h>

int main (){
int N,j;
char buffer[1000];
double key[100];
double x[9];


//x0,y0
int i=0;
fgets(buffer, 1000, stdin);
sscanf(buffer, "%d", &N);
while (NULL!=fgets(buffer, 1000, stdin)){
	sscanf(buffer,"%lf %lf", &key[i], &key[i+1]);
	i=i+2;
}

j=i;
double A8_[8][8]={
	{key[0],key[1],1,0,0,0,(-key[0]*key[8]),(-key[1]*key[8])},
	{0,0,0,key[0],key[1],1,(-key[0]*key[9]),(-key[1]*key[9])},
	{key[2],key[3],1,0,0,0,(-key[2]*key[10]),(-key[3]*key[10])},
	{0,0,0,key[2],key[3],1,(-key[2]*key[11]),(-key[3]*key[11])},
	{key[4],key[5],1,0,0,0,(-key[4]*key[12]),(-key[5]*key[12])},
	{0,0,0,key[4],key[5],1,(-key[4]*key[13]),(-key[5]*key[13])},
	{key[6],key[7],1,0,0,0,(-key[6]*key[14]),(-key[7]*key[14])},
	{0,0,0,key[6],key[7],1,(-key[6]*key[15]),(-key[7]*key[15])}
};

const double *A[8]={
	A8_[0],A8_[1],A8_[2],A8_[3],A8_[4],A8_[5],A8_[6],A8_[7]
};

const double b[8]={
	key[8],key[9],key[10],key[11],key[12],key[13],key[14],key[15]
};

N=8;
LUdecomp *LU = LUdecompose(N, A);
LUsolve(LU,b,x);
x[8]=1;
for(i=0;i<8;i+=3)
	printf("%lf %lf %lf\n", x[i],x[i+1],x[i+2]);

LUdestroy(LU);

}
