Michael Allen-Bond
m.allen-bond@email.wsu.edu
CSE 330

LUdecomp.c is a module that will decompose NxN matrixes, solve them, and dispose of them, if necessary.  It requires the header file LUdecomp.h, and I've packaged it with both that and Dr. Cochran's test program, LUtest.c.  This program can be compiled/tested by entering "make test" on the command line.

Output will display the the output and error for the 5x5, and error information for the 10x10 inverse (along with output ID matrix) and 600x600 error info.

Files in Archive:
Makefile
README
LUdecomp.c
LUdecomp.h
LUtest.c

